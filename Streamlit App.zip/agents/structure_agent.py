from agents.client import client

def document_structure_agent(document_text: str, format_template: str, model: str = "gpt-4o-mini") -> str:

    prompt = f"""
    You are an expert in analyzing technical documents and creating structured plans.
    Given the following document, extract the high-level structure and identify the Epics, Tasks, and Subtasks.

    INSTRUCTIONS:
    1. For each item, provide:
       - A short **title/summary** (max 10 words, concise, like a Jira title).
       - A **Description** (1–3 sentences, expanded from the document's content).
    2. Use one Epic as parent for all the Tasks. The Epic Represents the hole document.
    3. For Tasks that concerns tabular reports, include all the fields needed in the description and 
       relate no Subtasks to this Tasks.
    4. Return the result in a hierarchical format with an Epic as the parent, followed by Tasks and then Subtasks.
    5. Only return the structure in the specified format with no explanation.

    Use the following format as guide:
    {format_template}

    Document:
    {document_text}
    """

    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "You are a precise, structured planning assistant."},
            {"role": "user", "content": prompt}
        ],
        temperature=0,
        max_tokens=3000
    )

    return resp.choices[0].message.content.strip()