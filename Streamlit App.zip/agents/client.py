# agents/client.py
import os
from openai import OpenAI

def _get_api_key() -> str:
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        
        raise RuntimeError("OPENAI_API_KEY is not set")
    return key


client = OpenAI(api_key=_get_api_key())
