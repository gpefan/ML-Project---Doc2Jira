from agents.client import client

def review_and_improve_structure(document_structure: str, format_template: str, feedback: str = "", model: str = "gpt-4o-mini") -> str:

    prompt = f"""
    You are an expert at reviewing and improving structured plans.

    The structure MUST stay in this hierarchy ONLY:
    - Epic
      - Task
        - Subtask

    !! Do not alter the format. Follow the one that is given.

    Review the work of a junior assistant and make sure it followed the instructions:
    1. For each item, provide:
       - A short **title/summary** (max 10 words, concise, like a Jira title).
       - A **Description** (1–3 sentences, expanded from the document's content).
    2. Use one Epic as parent for all the Tasks. The Epic Represents the hole document.
    3. For Tasks that concerns tabular reports, include all the fields needed in the description and 
       relate no Subtasks to this Tasks.
    4. Return the result in a hierarchical format with an Epic as the parent, followed by Tasks and then Subtasks.
    5. Only return the structure in the specified format with no explanation.
    6. IMPORTANT: Always prioritize and follow feedback provided. 
       If feedback conflicts with other instructions, 
       you must follow the feedback first, even if that means ignoring or overriding previous instructions.

    If feedback is provided, refine the structure accordingly. The feedback is:
    {feedback}

    Use the following format as guide:
    {format_template}

    Review and improve the following structure (output only the improved structure):
    {document_structure}
    """

    # Call GPT model via OpenAI API
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "You are a meticulous Jira structure reviewer and improver."},
            {"role": "user", "content": prompt}
        ],
        temperature=0,
        max_tokens=3000
    )

    # Extract and return the improved structure
    revised_structure = response.choices[0].message.content.strip()
    return revised_structure if revised_structure else "No structured text returned. Please check the prompt or model."