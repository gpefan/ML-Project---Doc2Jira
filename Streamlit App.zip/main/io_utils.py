# main/io_utils.py
import io
from pathlib import Path
from typing import Union, Any
from docx import Document

def read_docx_text(file_or_path: Union[str, Path, Any]) -> str:
    """
    Διαβάζει .docx είτε από path είτε από Streamlit UploadedFile / file-like object.
    """
    if hasattr(file_or_path, "read"):
        data = file_or_path.read()
        try:
            file_or_path.seek(0)
        except Exception:
            pass
        doc = Document(io.BytesIO(data))
    else:
        doc = Document(str(file_or_path))

    parts = []
    for p in doc.paragraphs:
        t = (p.text or "").strip()
        if t:
            parts.append(t)
    return "\n".join(parts)

def load_schema_txt(path_or_file: Union[str, Path, Any]) -> str:
    """
    Διαβάζει .txt είτε από path είτε από Streamlit UploadedFile / file-like object.
    """
    if hasattr(path_or_file, "read"):
        data = path_or_file.read()
        try:
            path_or_file.seek(0)
        except Exception:
            pass
        return data.decode("utf-8", errors="replace") if isinstance(data, (bytes, bytearray)) else str(data)
    return Path(path_or_file).read_text(encoding="utf-8")
