# main/sql_tools.py
# -*- coding: utf-8 -*-

import re
import json
from typing import Optional, List, Dict, Any

import pandas as pd
from agents.client import client  # ο ενιαίος OpenAI OpenAI(...)

# --------------------------------------------------------------------------------------
# 1) Εντοπισμός missing fields για Reporting Tasks (χρησιμοποιεί LLM)
# --------------------------------------------------------------------------------------

def find_missing_fields_df_from_staging(
    df: pd.DataFrame,
    schema_text: str,
    model: str = "gpt-4o-mini"
) -> pd.DataFrame:
    """
    Σκανάρει μόνο τις γραμμές με label == 'Reporting' και ζητά από το LLM να επιστρέψει
    missing πεδία ως λίστα JSON αντικειμένων:
    [
      {"missing_field_name":"CustomerSegment","suggested_table":"customers"},
      ...
    ]
    Επιστρέφει DataFrame με στήλες: missing_field_name, suggested_table, parent_local_id
    (το parent_local_id είναι το local_id του Task).
    """

    required_cols = {"local_id", "summary", "description", "label"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Input df must contain columns: {missing}")

    df_filtered = df[df["label"].astype(str).str.strip().str.lower() == "reporting"]

    rows_out: List[Dict[str, str]] = []

    for _, row in df_filtered.iterrows():
        local_id    = str(row.get("local_id", "")).strip()
        summary     = (row.get("summary") or "").strip()
        description = (row.get("description") or "").strip()

        prompt = f"""
You analyze report specifications against an existing database schema and identify missing fields.

SCHEMA (human-readable text):
{schema_text.strip()}

ITEM CONTEXT:
Summary: {summary}
Description: {description}

TASK:
- If this report clearly requires columns NOT present in the schema, list them.
- For each missing field, return:
  • missing_field_name (as mentioned in the report)
  • suggested_table (existing table if appropriate, else a sensible new table name)
- If nothing is missing, return an empty array.

OUTPUT:
Return ONLY valid JSON array, like:
[
  {{"missing_field_name":"CustomerSegment","suggested_table":"customers"}}
]
""".strip()

        resp = client.chat.completions.create(
            model=model,
            temperature=0,
            max_tokens=800,
            messages=[
                {"role": "system", "content": "You compare report requirements to schemas and output only valid JSON arrays."},
                {"role": "user", "content": prompt}
            ],
        )

        text = (resp.choices[0].message.content or "").strip()
        # parse JSON array; fallback: extract first [...] block
        try:
            data = json.loads(text)
        except Exception:
            m = re.search(r"\[\s*{.*}\s*\]", text, flags=re.DOTALL)
            data = json.loads(m.group(0)) if m else []

        if isinstance(data, list):
            for item in data:
                rows_out.append({
                    "missing_field_name":   (item.get("missing_field_name") or "").strip(),
                    "suggested_table":      (item.get("suggested_table") or "").strip(),
                    "parent_local_id":      local_id
                })

    out = pd.DataFrame(rows_out, columns=[
        "missing_field_name", "suggested_table", "parent_local_id"
    ])

    if out.empty:
        return out

    # Normalization → CamelCase (κρατάμε ακρώνυμα έως 4 γράμματα ως ALLCAPS)
    def camelize(name: str) -> str:
        tokens = re.findall(r"[A-Za-z0-9]+", (name or ""))
        parts = [t if t.isupper() and len(t) <= 4 else t.capitalize() for t in tokens]
        return "".join(parts)

    out["missing_field_name"] = out["missing_field_name"].apply(camelize)

    # Deduplicate by normalized missing_field_name
    out = out.drop_duplicates(subset=["missing_field_name"], keep="first").reset_index(drop=True)
    return out


# --------------------------------------------------------------------------------------
# 2) Helper: Εύρεση local_id των standardized Subtasks ("Add field ...")
# --------------------------------------------------------------------------------------

def attach_subtask_local_ids(fields_df: pd.DataFrame, staging_df: pd.DataFrame) -> pd.DataFrame:
    """
    Δένει στα rows του fields_df (missing_field_name, suggested_table, parent_local_id)
    το local_id του αντίστοιχου Subtask στο staging_df που έχει summary:
    'Add field "<missing_field_name>" to table "<suggested_table>"'
    """
    need_f = {"missing_field_name", "suggested_table", "parent_local_id"}
    missing = need_f - set(fields_df.columns)
    if missing:
        raise ValueError(f"fields_df missing columns: {missing}")

    need_s = {"local_id", "summary", "issue_type", "parent_local_id"}
    missing_s = need_s - set(staging_df.columns)
    if missing_s:
        raise ValueError(f"staging_df missing columns: {missing_s}")

    out = fields_df.copy()
    out["local_id"] = ""

    subs = staging_df[staging_df["issue_type"] == "Subtask"][["local_id","summary","parent_local_id"]].copy()

    for idx, r in out.iterrows():
        fname = str(r["missing_field_name"]).strip()
        tname = str(r["suggested_table"]).strip()
        parent = str(r["parent_local_id"]).strip()
        expected_summary = f'Add field "{fname}" to table "{tname}"'

        hit = subs[(subs["summary"] == expected_summary) & (subs["parent_local_id"].astype(str) == parent)]
        if not hit.empty:
            out.at[idx, "local_id"] = str(hit.iloc[0]["local_id"])

    return out


# --------------------------------------------------------------------------------------
# 3) Παραγωγή ALTER TABLE για κάθε standardized subtask
# --------------------------------------------------------------------------------------

def generate_alter_sql_per_field_from_staging(
    fields_df: pd.DataFrame,
    staging_df: pd.DataFrame,
    schema_text: str,
    model: str = "gpt-4o-mini"
) -> pd.DataFrame:
    """
    Για κάθε row του fields_df βρίσκει το αντίστοιχο Subtask στο staging_df (με attach_subtask_local_ids),
    ζητά από το LLM να δημιουργήσει ένα ALTER TABLE ... ADD ...; (single-line), και επιστρέφει:
    columns: local_id, field_name, suggested_table, sql_script
    """
    merged = attach_subtask_local_ids(fields_df, staging_df)

    out_rows: List[Dict[str, str]] = []
    for _, r in merged.iterrows():
        sub_local_id = (r.get("local_id") or "").strip()
        if not sub_local_id:
            continue

        field_name = str(r["missing_field_name"]).strip()
        table_name = str(r["suggested_table"]).strip()

        prompt = f"""
You write concise ANSI SQL DDL.

Schema (human-readable for context):
{schema_text}

Task:
Write ONE single-line ALTER TABLE statement to add the column below to the target table.
- If type/length is unclear, choose a sensible default (e.g., VARCHAR(100) or BOOLEAN or DATE).
- Default to NULL unless clearly NOT NULL.
- Do NOT include comments or code fences. End with a semicolon.

Column to add:
- Table: {table_name}
- Column: {field_name}

Output:
A single ALTER TABLE ... ADD ...; statement, nothing else.
""".strip()

        resp = client.chat.completions.create(
            model=model,
            temperature=0,
            max_tokens=200,
            messages=[
                {"role": "system", "content": "Return only one ANSI SQL ALTER statement; no explanations."},
                {"role": "user", "content": prompt}
            ],
        )

        sql = (resp.choices[0].message.content or "").strip()
        # Clean any accidental code fences/spaces
        sql = re.sub(r"^```[\s\S]*?\n", "", sql)
        sql = re.sub(r"\n```$", "", sql)
        sql = sql.strip()
        if not sql.endswith(";"):
            sql += ";"

        out_rows.append({
            "local_id": sub_local_id,
            "field_name": field_name,
            "suggested_table": table_name,
            "sql_script": sql
        })

    return pd.DataFrame(out_rows, columns=["local_id", "field_name", "suggested_table", "sql_script"])


# --------------------------------------------------------------------------------------
# 4) Σήμανση ποια Tasks είναι Tabular Reports
# --------------------------------------------------------------------------------------

def identify_tabular_reports(staging_df: pd.DataFrame, model: str = "gpt-4o-mini") -> pd.DataFrame:
    """
    Βάζει στήλη staging_df['is_tabular_report'] = True/False ΜΟΝΟ αν label == 'Reporting'
    και το LLM κρίνει ότι περιγράφεται πίνακας/SELECT report.
    """
    rows: List[bool] = []
    for _, r in staging_df.iterrows():
        if str(r.get("label", "")).strip().lower() != "reporting":
            rows.append(False)
            continue

        context = f"Summary: {r.get('summary','')}\nDescription: {r.get('description','')}"
        prompt = f"""
You are an analyst.
Determine if the following describes a TABULAR REPORT (e.g. SELECT query with multiple fields).
Respond ONLY with true or false.

CONTEXT:
{context}
"""
        resp = client.chat.completions.create(
            model=model,
            temperature=0,
            max_tokens=5,
            messages=[
                {"role": "system", "content": "Return only 'true' or 'false'."},
                {"role": "user", "content": prompt}
            ],
        )
        text = (resp.choices[0].message.content or "").strip().lower()
        rows.append(text.startswith("t"))

    staging_df["is_tabular_report"] = rows
    return staging_df


# --------------------------------------------------------------------------------------
# 5) Παραγωγή SELECT SQL για τα tabular report Tasks
# --------------------------------------------------------------------------------------

def generate_select_sql_for_reports(
    staging_df: pd.DataFrame,
    schema_text: str,
    fields_df: Optional[pd.DataFrame] = None,
    model: str = "gpt-4o-mini"
) -> pd.DataFrame:
    """
    Για κάθε Task με is_tabular_report=True, ζητά από το LLM να παράξει ρεαλιστικό ANSI SQL SELECT,
    με βάση το schema_text και προαιρετικά mapped fields από fields_df (parent_local_id → [(field, table)]).
    Γράφει το αποτέλεσμα σε νέα/υπάρχουσα στήλη staging_df['sql_script'] (δεν κάνει overwrite αν υπάρχει ήδη).
    """
    out_rows: List[Dict[str, str]] = []

    # parent_local_id -> [(field, table), ...]
    field_map: Dict[str, List[tuple[str, str]]] = {}
    if fields_df is not None and not fields_df.empty:
        for _, f in fields_df.iterrows():
            parent = str(f.get("parent_local_id") or "").strip()
            field_map.setdefault(parent, []).append(
                (str(f.get("missing_field_name") or "").strip(),
                 str(f.get("suggested_table") or "").strip())
            )

    for _, r in staging_df.iterrows():
        if not bool(r.get("is_tabular_report")):
            continue

        local_id = str(r["local_id"])
        context = f"Summary: {r.get('summary','')}\nDescription: {r.get('description','')}"

        # Attach schema mapping info if available for this task/local_id
        extra_fields = field_map.get(local_id, [])
        mapping_text = ""
        if extra_fields:
            lines = [f"- {col} (from {tbl})" for col, tbl in extra_fields if col and tbl]
            if lines:
                mapping_text = "\nMapped fields from schema:\n" + "\n".join(lines)

        prompt = f"""
You are a SQL expert.
Write a realistic ANSI SQL SELECT statement for the following tabular report.
Use tables and joins consistent with this schema:
{schema_text}
{mapping_text}

Report requirement:
{context}

Output:
- Return ONLY the SQL query (no explanation, no markdown).
- Include sensible JOINs based on the schema.
- Try using fields from the schema or the mapped fields before computing derived fields.
- Use aliases when helpful.
""".strip()

        resp = client.chat.completions.create(
            model=model,
            temperature=0,
            max_tokens=600,
            messages=[
                {"role": "system", "content": "Return only the SQL query; no extra text."},
                {"role": "user", "content": prompt}
            ],
        )

        sql = (resp.choices[0].message.content or "").strip()
        sql = re.sub(r"^```sql\s*", "", sql, flags=re.IGNORECASE)
        sql = re.sub(r"^```", "", sql)
        sql = re.sub(r"```$", "", sql)
        sql = sql.replace("\\n", "\n").strip()
        sql = re.sub(r"\n{3,}", "\n\n", sql)

        out_rows.append({"local_id": local_id, "sql_script": sql})

    if out_rows:
        sql_df = pd.DataFrame(out_rows)

        if "sql_script" not in staging_df.columns:
            staging_df["sql_script"] = None

        staging_df = staging_df.merge(sql_df, on="local_id", how="left", suffixes=("", "_new"))
        staging_df["sql_script"] = staging_df["sql_script"].combine_first(staging_df["sql_script_new"])
        staging_df = staging_df.drop(columns=["sql_script_new"], errors="ignore")

    return staging_df
# --- Βάλε αυτό το block μέσα στο main/sql_tools.py (π.χ. κάτω από τα άλλα helpers) ---

import re
import pandas as pd

def append_add_field_subtasks_interactive(
    fields_df: pd.DataFrame,
    staging_df: pd.DataFrame,
    *,
    default_label: str = "Data",
    default_group: str = "Data Warehouse Team"
) -> pd.DataFrame:
    """
    Streamlit-safe εκδοχή: ΔΕΝ ρωτάει τον χρήστη με input().
    Παίρνει τα ήδη επιλεγμένα rows του fields_df και τα προσθέτει ως standardized Subtasks στο staging_df.

    fields_df: columns -> missing_field_name, suggested_table, parent_local_id
    staging_df: columns -> local_id, summary, description, issue_type, parent_local_id, (προαιρετικά label, assignee_group)
    """

    required_cols = {"missing_field_name", "suggested_table", "parent_local_id"}
    missing = required_cols - set(fields_df.columns)
    if missing:
        raise ValueError(f"fields_df missing columns: {missing}")

    df = staging_df.copy()

    # Helper: επόμενο διαθέσιμο local_id τύπου U<number>
    def next_sub_id(existing_ids: pd.Series) -> str:
        max_n = 0
        for v in existing_ids.dropna().astype(str):
            m = re.match(r"U(\d+)$", v.strip(), re.IGNORECASE)
            if m:
                max_n = max(max_n, int(m.group(1)))
        return f"U{max_n + 1}"

    # Πρόσθεσε ένα subtask ανά γραμμή
    for _, row in fields_df.iterrows():
        field_name = str(row["missing_field_name"]).strip()
        table_name = str(row["suggested_table"]).strip()
        parent_id = str(row["parent_local_id"]).strip()

        # φτιάξε unique local_id
        new_id = next_sub_id(df["local_id"]) if "local_id" in df.columns else "U1"

        summary = f'Add field "{field_name}" to table "{table_name}"'
        description = (
            f'Implement changes to add the field "{field_name}" into table "{table_name}", '
            f'including ETL and database updates.'
        )

        new_row = {
            "local_id": new_id,
            "summary": summary,
            "description": description,
            "issue_type": "Subtask",
            "parent_local_id": parent_id,
        }

        # αν υπάρχουν στήλες label/assignee_group στο staging_df, γέμισέ τες
        if "label" in df.columns:
            new_row["label"] = default_label
        if "assignee_group" in df.columns:
            new_row["assignee_group"] = default_group

        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

    return df
