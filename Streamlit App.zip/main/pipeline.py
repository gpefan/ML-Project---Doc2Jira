# main/pipeline.py
import re
import pandas as pd
from typing import List, Dict, Any
from agents.client import client

# ---------- Structure → DF ----------

def parse_structure_text(structure_text: str) -> List[Dict[str, Any]]:
    epics: List[Dict[str, Any]] = []
    current_epic = None
    current_task = None
    current_subtask = None
    last_node = None

    raw_lines = structure_text.splitlines()
    lines = [ln.rstrip() for ln in raw_lines]

    def start_node(node_type: str, summary: str) -> Dict[str, Any]:
        node = {"summary": summary.strip(), "description": ""}
        if node_type == "epic":
            node["tasks"] = []
        elif node_type == "task":
            node["subtasks"] = []
        return node

    p_epic    = re.compile(r"^\s*(?:[-•]\s*)?Epic:\s*(.+)$", re.IGNORECASE)
    p_story   = re.compile(r"^\s*(?:[-•]\s*)?Story:\s*(.+)$", re.IGNORECASE)   # treated as Task
    p_task    = re.compile(r"^\s*(?:[-•]\s*)?Task:\s*(.+)$", re.IGNORECASE)
    p_subtask = re.compile(r"^\s*(?:[-•]\s*)?Sub[- ]?task:\s*(.+)$", re.IGNORECASE)
    p_desc    = re.compile(r"^\s*Description:\s*(.*)$", re.IGNORECASE)

    for ln in lines:
        if not ln.strip():
            if last_node is not None and last_node["description"]:
                last_node["description"] += "\n"
            continue

        line_no_bullet = re.sub(r"^\s*[-•]\s*", "", ln)

        m_epic = p_epic.match(ln)
        m_story = p_story.match(ln)
        m_task = p_task.match(ln)
        m_sub = p_subtask.match(ln)
        m_desc = p_desc.match(ln)

        if m_epic:
            current_epic = start_node("epic", m_epic.group(1))
            epics.append(current_epic)
            current_task = None
            current_subtask = None
            last_node = current_epic
            continue

        if m_story or m_task:
            if not current_epic:
                current_epic = start_node("epic", "Miscellaneous Epic")
                epics.append(current_epic)
            title = (m_story or m_task).group(1)
            current_task = start_node("task", title)
            current_epic["tasks"].append(current_task)
            current_subtask = None
            last_node = current_task
            continue

        if m_sub:
            if not current_task:
                if not current_epic:
                    current_epic = start_node("epic", "Miscellaneous Epic")
                    epics.append(current_epic)
                current_task = start_node("task", "General Task")
                current_epic["tasks"].append(current_task)
            current_subtask = {"summary": m_sub.group(1).strip(), "description": ""}
            current_task["subtasks"].append(current_subtask)
            last_node = current_subtask
            continue

        if m_desc:
            if last_node is not None:
                last_node["description"] = m_desc.group(1).strip()
            continue

        if last_node is not None:
            if last_node["description"]:
                last_node["description"] += ("\n" + line_no_bullet)
            else:
                last_node["description"] = line_no_bullet

    return epics

def flatten_to_staging_rows(parsed: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    epic_i = task_i = sub_i = 0

    for epic in parsed:
        epic_i += 1
        e_id = f"E{epic_i}"
        rows.append({
            "local_id": e_id,
            "summary": epic.get("summary", ""),
            "description": epic.get("description", "").strip(),
            "issue_type": "Epic",
            "parent_local_id": ""
        })

        for task in epic.get("tasks", []):
            task_i += 1
            t_id = f"T{task_i}"
            rows.append({
                "local_id": t_id,
                "summary": task.get("summary", ""),
                "description": task.get("description", "").strip(),
                "issue_type": "Task",
                "parent_local_id": e_id
            })

            for sub in task.get("subtasks", []):
                sub_i += 1
                u_id = f"U{sub_i}"
                rows.append({
                    "local_id": u_id,
                    "summary": sub.get("summary", ""),
                    "description": sub.get("description", "").strip(),
                    "issue_type": "Subtask",
                    "parent_local_id": t_id
                })
    return rows

def build_staging_dataframe(structure_text: str) -> pd.DataFrame:
    parsed = parse_structure_text(structure_text)
    rows = flatten_to_staging_rows(parsed)
    return pd.DataFrame(rows, columns=[
        "local_id", "summary", "description", "issue_type", "parent_local_id"
    ])

# ---------- Labels / Groups / Priority ----------

_labels_list = ["QA", "Reporting", "ETL", "Data", "Development", "Documentation", "Business"]
_groups_list = [
    "Business Analysis Team",
    "Business Intelligence Team",
    "Configuration Engineer Team",
    "Data Warehouse Team",
    "Project Management Office (PMO)",
    "Quality Assurance Team",
]
_allowed_priorities = ["Highest", "High", "Medium", "Low", "Lowest"]

def add_labels_to_dataframe(df: pd.DataFrame, model: str = "gpt-4o-mini") -> pd.DataFrame:
    df = df.copy()
    df["label"] = None
    for idx, row in df.iterrows():
        context = f"Summary: {row['summary']}\nDescription: {row['description']}"
        prompt = f"""
You are an expert at categorizing work items.
Choose ONE label from this list: {", ".join(_labels_list)}
Return only the label.
Context:
{context}
"""
        resp = client.chat.completions.create(
            model=model, temperature=0, max_tokens=32,
            messages=[
                {"role":"system","content":"You are a precise classifier that returns only one label."},
                {"role":"user","content":prompt}
            ]
        )
        label = (resp.choices[0].message.content or "").strip()
        df.at[idx, "label"] = label
    return df

def add_groups_to_dataframe(df: pd.DataFrame, model: str = "gpt-4o-mini") -> pd.DataFrame:
    df2 = df.copy()
    df2["assignee_group"] = None
    for idx, row in df2.iterrows():
        summary = (row.get("summary") or "").strip()
        description = (row.get("description") or "").strip()
        label = (row.get("label") or "").strip() if "label" in df2.columns else ""
        context = f"Summary: {summary}\nDescription: {description}\nLabel: {label}"

        prompt = f"""
You are assigning each work item to exactly ONE delivery group.
Choose ONE group from: {", ".join(_groups_list)}
Return ONLY the group name.
Item:
{context}
"""
        resp = client.chat.completions.create(
            model=model, temperature=0, max_tokens=16,
            messages=[
                {"role":"system","content":"You are a precise triage assistant. Output exactly one allowed group."},
                {"role":"user","content":prompt}
            ]
        )
        group = (resp.choices[0].message.content or "").strip()
        df2.at[idx, "assignee_group"] = group
    return df2

def add_priority_predictions(df: pd.DataFrame, model: str = "gpt-4o-mini") -> pd.DataFrame:
    df2 = df.copy()
    by_local = {str(r.local_id): r for _, r in df2.iterrows()}
    child_count = {}
    for _, r in df2.iterrows():
        parent = str(r.get("parent_local_id") or "").strip()
        if parent:
            child_count[parent] = child_count.get(parent, 0) + 1

    priorities = []
    for _, r in df2.iterrows():
        local_id     = str(r.get("local_id") or "")
        summary      = (r.get("summary") or "").strip()
        description  = (r.get("description") or "").strip()
        issue_type   = (r.get("issue_type") or "").strip()
        label        = (r.get("label") or "").strip()
        parent_id    = (r.get("parent_local_id") or "").strip()
        parent_type  = (by_local.get(parent_id).issue_type if parent_id in by_local else "") or ""
        parent_sum   = (by_local.get(parent_id).summary if parent_id in by_local else "") or ""
        has_children = child_count.get(local_id, 0) > 0

        context = f"""IssueType: {issue_type}
Summary: {summary}
Description: {description}
Label: {label}
Parent: {parent_id} ({parent_type}) {parent_sum}
HasChildren: {has_children}"""

        prompt = f"""
You are a Jira triage assistant. Assign a PRIORITY to this work item.
Allowed values: Highest | High | Medium | Low | Lowest
Do NOT default to Medium.
Item:
{context}
"""
        resp = client.chat.completions.create(
            model=model, temperature=0, max_tokens=8,
            messages=[
                {"role":"system","content":"Return only one of: Highest | High | Medium | Low | Lowest"},
                {"role":"user","content":prompt}
            ]
        )
        raw = (resp.choices[0].message.content or "").strip()
        choice = next((p for p in _allowed_priorities if p.lower() == raw.lower()), None)
        priorities.append(choice or "Medium")
    df2["priority"] = priorities
    return df2
