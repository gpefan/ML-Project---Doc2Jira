# main/jira_client.py
import os
import re
from pathlib import Path
from typing import Optional, Dict, List

import pandas as pd
import requests
from requests.auth import HTTPBasicAuth


# =========================================================
# Jira env (απλό): base, email, token, proj, assigned_group_cf (optional)
# =========================================================
def _jira_env(explicit: Optional[dict] = None) -> dict:
    if explicit is not None:
        out = explicit.copy()
        out["base"] = (out.get("base", "") or "").strip().rstrip("/")
        out["email"] = (out.get("email", "") or "").strip()
        out["token"] = (out.get("token", "") or "").strip()
        out["proj"]  = (out.get("proj", "") or "").strip()
        out["assigned_group_cf"] = (out.get("assigned_group_cf", "") or "").strip()
        return out

    base  = (os.environ.get("JIRA_BASE_URL", "") or "").strip().rstrip("/")
    email = (os.environ.get("JIRA_EMAIL", "") or "").strip()
    token = (os.environ.get("JIRA_API_TOKEN", "") or "").strip()
    proj  = (os.environ.get("JIRA_PROJECT_KEY", "") or "").strip()
    assigned_group_cf = (os.environ.get("JIRA_FIELD_ASSIGNED_GROUP", "") or "").strip()

    return {
        "base": base,
        "email": email,
        "token": token,
        "proj": proj,
        "assigned_group_cf": assigned_group_cf,
    }


# ---------------------------------------------------------
# Upload Attachments to Jira
# ---------------------------------------------------------
def upload_attachment_to_issue(issue_key: str, file_path: str, jira_env: Optional[dict] = None) -> bool:
    env = _jira_env(jira_env)
    if not env["base"]:
        raise RuntimeError("JIRA_BASE_URL is not set.")
    if not env["email"] or not env["token"]:
        raise RuntimeError("JIRA_EMAIL / JIRA_API_TOKEN are not set.")

    url = f'{env["base"]}/rest/api/3/issue/{issue_key}/attachments'
    headers = {"Accept": "application/json", "X-Atlassian-Token": "no-check"}
    auth = HTTPBasicAuth(env["email"], env["token"])

    with open(file_path, "rb") as f:
        files = {"file": (os.path.basename(file_path), f, "application/octet-stream")}
        r = requests.post(url, headers=headers, auth=auth, files=files)

    ok = r.status_code in (200, 201)
    if ok:
        print(f"\nAttached {os.path.basename(file_path)} → {issue_key}")
    else:
        try:
            print("Attachment failed:", r.status_code, r.json())
        except Exception:
            print("Attachment failed:", r.status_code, r.text)
    return ok


# ---------------------------------------------------------
# Create Single Jira Issue (Epic/Task/Subtask)
# ---------------------------------------------------------
def create_jira_issue(summary: str,
                      description: Optional[str],
                      issue_type: str,                        # "Epic" | "Task" | "Subtask"
                      parent_key: Optional[str] = None,       # Epic for Tasks, Task for Subtasks
                      labels: Optional[List[str]] = None,
                      assigned_group: Optional[str] = None,   # optional; only sent if assigned_group_cf provided
                      jira_env: Optional[dict] = None) -> Optional[str]:

    env = _jira_env(jira_env)

    def _auth(): return HTTPBasicAuth(env["email"], env["token"])
    def _headers(): return {"Accept": "application/json", "Content-Type": "application/json"}

    def _to_adf(text):
        if not text:
            return None
        blocks = []
        for line in str(text).split("\n"):
            if line.strip():
                blocks.append({"type": "paragraph", "content": [{"type": "text", "text": line}]}),
            else:
                blocks.append({"type": "paragraph", "content": []})
        while blocks and blocks[-1].get("content") == []:
            blocks.pop()
        if not blocks:
            blocks = [{"type": "paragraph"}]
        return {"type": "doc", "version": 1, "content": blocks}

    def _post(fields):
        if not env["base"]:
            raise RuntimeError("JIRA_BASE_URL is not set.")
        if not env["email"] or not env["token"]:
            raise RuntimeError("JIRA_EMAIL / JIRA_API_TOKEN are not set.")
        url = f'{env["base"]}/rest/api/3/issue'
        return requests.post(url, json={"fields": fields}, auth=_auth(), headers=_headers())

    # Normalize a Jira label (no spaces)
    def _norm_label(s: str) -> str:
        s = (s or "").strip().lower()
        s = re.sub(r"\s+", "-", s)
        s = re.sub(r"[^a-z0-9._-]", "", s)
        return s

    # ---- normalize issuetype ----
    t = issue_type.strip().lower()
    if t in ("sub-task", "subtask"):
        issuetype_name = "Subtask"
    elif t == "story":
        issuetype_name = "Task"
    else:
        issuetype_name = issue_type

    # ---- base fields ----
    fields = {
        "project": {"key": env["proj"]},
        "summary": summary,
        "issuetype": {"name": issuetype_name},
    }
    adf = _to_adf(description)
    if adf:
        fields["description"] = adf

    # Jira labels (standard field expects list[str])
    if labels:
        safe_labels = [_norm_label(x) for x in labels if isinstance(x, str) and x.strip()]
        if safe_labels:
            fields["labels"] = safe_labels

    # Assigned Group (custom field) — OPTIONAL only if cf id provided and value exists
    assigned_group_cf = env["assigned_group_cf"]
    assigned_group_value = (assigned_group or "").strip()
    if assigned_group_cf and assigned_group_value:
        # συνήθως select-list σχήμα
        fields[assigned_group_cf] = {"value": assigned_group_value}

    # Parent (Tasks→Epic, Subtasks→Task)
    if parent_key and issuetype_name.lower() != "epic":
        fields["parent"] = {"key": parent_key}

    # ---- create (attempt 1) ----
    r = _post(fields)
    if r.status_code == 201:
        key = r.json().get("key")
        print(f"Created {issuetype_name}: {key}")
        return key

    # Διαχείριση: parent σε company-managed, assigned group shape fallback
    retry_parent = False
    retry_assigned_group = False
    try:
        body = r.json()
        if isinstance(body, dict) and "errors" in body:
            if "parent" in body["errors"] or any("parent" in (str(v) or "") for v in body["errors"].values()):
                retry_parent = True
            if assigned_group_cf and assigned_group_cf in body["errors"]:
                retry_assigned_group = True
    except Exception:
        pass

    fields_retry = dict(fields)

    # Fallback: assigned group ως {"name": "..."} (group picker)
    if retry_assigned_group and assigned_group_cf and assigned_group_value:
        ag = fields_retry.get(assigned_group_cf)
        if isinstance(ag, dict) and "value" in ag:
            fields_retry[assigned_group_cf] = {"name": assigned_group_value}

    # Fallback: αφαίρεσε parent για μη-Subtask σε company-managed
    if retry_parent and parent_key and issuetype_name.lower() != "subtask":
        fields_retry.pop("parent", None)

    if retry_parent or retry_assigned_group:
        r2 = _post(fields_retry)
        if r2.status_code == 201:
            key = r2.json().get("key")
            return key
        else:
            try:
                body2 = r2.json()
            except Exception:
                body2 = r2.text
            print(f"Failed to create {issuetype_name} on retry. Status:", r2.status_code)
            print("Response:", body2)
            return None

    # Τελική αποτυχία
    try:
        body = r.json()
    except Exception:
        body = r.text
    print(f"Failed to create {issuetype_name}. Status:", r.status_code)
    print("Response:", body)
    return None


# ---------------------------------------------------------
# Create Issues from DataFrame (Epic → Task → Subtask)
# ---------------------------------------------------------
def create_jira_from_df(df: pd.DataFrame, *, attach_sql: bool = True, sql_dir: str = "sql_scripts",
                        jira_env: Optional[dict] = None) -> Dict:
    required = {"local_id", "summary", "description", "issue_type", "parent_local_id"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Staging DataFrame missing columns: {missing}")

    with pd.option_context("display.max_colwidth", 200, "display.width", 160):
        try:
            from IPython.display import display  # όταν τρέχεις σε notebook
            print("\nHere is the Jira ticketing structure, with the extra subtasks:\n")
            display(df.drop(columns=["sql_script","is_tabular_report"], errors="ignore"))
        except Exception:
            pass

    id_map: Dict[str, str] = {}

    def _row_label(row):
        if "label" in df.columns:
            val = (row.get("label") or "").strip()
            return [val] if val else None
        return None

    def _row_group(row):
        if "assignee_group" in df.columns:
            return (row.get("assignee_group") or "").strip() or None
        return None

    def _slug(s: str) -> str:
        s = (s or "").strip().lower()
        s = re.sub(r"[^a-z0-9]+", "_", s)
        return re.sub(r"_+", "_", s).strip("_") or "script"

    def _save_sql_file(jira_key: str, summary: str, sql_text: str) -> str:
        Path(sql_dir).mkdir(parents=True, exist_ok=True)
        fname = f"{jira_key}_{_slug(summary)}.sql"
        path = Path(sql_dir) / fname
        sql_clean = sql_text.rstrip()
        if not sql_clean.endswith(";"):
            sql_clean += ";"
        path.write_text(sql_clean + "\n", encoding="utf-8")
        return str(path)

    def _create_issue_with_sql(row, issue_type: str, parent_key: Optional[str] = None):
        jira_key = create_jira_issue(
            summary=(row.summary or "").strip(),
            description=(row.description or "").strip(),
            issue_type=issue_type,
            parent_key=parent_key,
            labels=_row_label(row),
            assigned_group=_row_group(row),   # optional
            jira_env=jira_env
        )
        id_map[str(row.local_id)] = jira_key
        print(f"\n{issue_type} created:", jira_key)

        if attach_sql and jira_key and "sql_script" in df.columns:
            raw_sql_val = row.get("sql_script", None)
            if not pd.isna(raw_sql_val):
                sql_text = str(raw_sql_val).strip()
                if sql_text and sql_text.lower() != "nan":
                    try:
                        file_path = _save_sql_file(jira_key, (row.summary or ""), sql_text)
                        upload_attachment_to_issue(jira_key, file_path, jira_env=jira_env)
                    except Exception as ex:
                        print(f"Warning: failed to attach SQL for {jira_key}: {ex}")

        return jira_key

    # 1) Epics
    for _, e in df[df.issue_type == "Epic"].iterrows():
        _create_issue_with_sql(e, "Epic")

    # 2) Tasks (parent = Epic)
    for _, t in df[df.issue_type == "Task"].iterrows():
        parent_local = str(t.parent_local_id or "")
        epic_key = id_map.get(parent_local)
        _create_issue_with_sql(t, "Task", parent_key=epic_key)

    # 3) Subtasks (parent = Task)
    for _, s in df[df.issue_type == "Subtask"].iterrows():
        parent_local = str(s.parent_local_id or "")
        parent_task_key = id_map.get(parent_local)
        _create_issue_with_sql(s, "Subtask", parent_key=parent_task_key)

    return id_map
