# main/viz_utils.py
from pyvis.network import Network

def render_jira_hierarchy_tree(df, height: str = "650px", direction: str = "UD") -> str:
    """
    Render Epic → Task → Subtask hierarchy tree using pyvis.
    Returns HTML string for embedding in Streamlit.
    """
    if df is None or df.empty:
        return "<p>No data to visualize.</p>"

    net = Network(height=height, directed=True, notebook=False)
    net.toggle_physics(False)

    # Map local_id → summary
    summaries = {row.local_id: row.summary for _, row in df.iterrows()}

    # Add nodes
    for _, row in df.iterrows():
        color = "#f39c12" if row.issue_type == "Epic" else \
                "#3498db" if row.issue_type == "Task" else "#2ecc71"
        net.add_node(row.local_id, label=f"{row.summary}\n({row.issue_type})", color=color)

    # Add edges (parent → child)
    for _, row in df.iterrows():
        parent = row.get("parent_local_id")
        if parent and parent in summaries:
            net.add_edge(parent, row.local_id)

    # Layout direction
    if direction == "LR":
        net.set_options("""var options = { "layout": { "hierarchical": { "enabled": true, "direction": "LR" }}}""")
    else:
        net.set_options("""var options = { "layout": { "hierarchical": { "enabled": true, "direction": "UD" }}}""")

    return net.generate_html()
