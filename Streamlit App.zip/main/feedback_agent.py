# main/feedback_agent.py
import re
import json
import pandas as pd
from typing import List, Dict, Any, Optional
from agents.client import client


def apply_feedback_to_dataframe_values(
    df: pd.DataFrame,
    feedback: str,
    *,
    model: str = "gpt-4o-mini",
    allowed_columns: Optional[List[str]] = None,
    extra_context_columns: Optional[List[str]] = None,
    temperature: float = 0.0
) -> pd.DataFrame:
    """
    Εφαρμόζει feedback του χρήστη σε ΣΥΓΚΕΚΡΙΜΕΝΕΣ στήλες του DataFrame.
    Δεν αλλάζει ποτέ: local_id, issue_type, parent_local_id (δομή).
    """
    if allowed_columns is None:
        allowed_columns = ["label", "assignee_group", "priority", "summary", "description"]

    if extra_context_columns is None:
        extra_context_columns = ["label", "assignee_group", "priority"]

    protected = {"local_id", "issue_type", "parent_local_id"}
    df2 = df.copy()

    # επιτρέπουμε μόνο columns που υπάρχουν και δεν είναι protected
    allowed_columns = [c for c in allowed_columns if c not in protected and c in df2.columns]

    system_msg = (
        "You are a careful data editor. You will update ONLY the specified columns in a row, "
        "following the user's feedback. Do not add or remove rows. "
        "Never change 'local_id', 'issue_type', or 'parent_local_id'. "
        "Return a JSON object with only the keys that need to be updated for this row. "
        "If no changes are required, return {}."
    )

    instructions = f"""
User feedback (apply globally where appropriate, but decide per-row by context):
{feedback}

Rules:
- Do NOT modify: local_id, issue_type, parent_local_id.
- You MAY modify only these columns if present: {allowed_columns}.
- Output MUST be a SINGLE JSON object with only the fields to change for this row.
- If no change needed, output: {{}}
""".strip()

    updates: List[Dict[str, Any]] = []
    for _, row in df2.iterrows():
        row_dict = row.to_dict()

        ctx = {
            "local_id": row_dict.get("local_id"),
            "issue_type": row_dict.get("issue_type"),
            "parent_local_id": row_dict.get("parent_local_id"),
            "summary": row_dict.get("summary", ""),
            "description": row_dict.get("description", ""),
        }
        for c in extra_context_columns:
            if c in row_dict:
                ctx[c] = row_dict[c]

        user_msg = (
            "Row context:\n"
            + json.dumps(ctx, ensure_ascii=False)
            + "\n\nAllowed output keys: "
            + ", ".join(allowed_columns)
        )

        resp = client.chat.completions.create(
            model=model,
            temperature=temperature,
            max_tokens=150,
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": instructions},
                {"role": "user", "content": user_msg},
            ],
        )

        raw = (resp.choices[0].message.content or "").strip()
        # καθάρισε τυχόν fences
        raw = re.sub(r"^```json\s*", "", raw, flags=re.IGNORECASE).strip()
        raw = re.sub(r"^```", "", raw).strip()
        raw = re.sub(r"```$", "", raw).strip()

        try:
            delta = json.loads(raw)
            if not isinstance(delta, dict):
                delta = {}
        except Exception:
            delta = {}

        clean_delta = {k: v for k, v in delta.items() if k in allowed_columns}
        updates.append(clean_delta)

    # συγχώνευση ενημερώσεων
    for i, upd in enumerate(updates):
        if upd:
            for k, v in upd.items():
                df2.iat[i, df2.columns.get_loc(k)] = v

    return df2
