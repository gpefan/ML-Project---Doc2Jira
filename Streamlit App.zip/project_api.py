# project_api.py
import os
from typing import Optional, Dict

import pandas as pd

# --- LLM Agents ---
from agents.structure_agent import document_structure_agent as _doc_struct_agent
from agents.review_agent import review_and_improve_structure as _review_agent

# --- Pipeline / Enrichment (non-SQL) ---
from main.pipeline import (
    build_staging_dataframe as _build_staging_dataframe,
    add_labels_to_dataframe as _add_labels_to_dataframe,
    add_groups_to_dataframe as _add_groups_to_dataframe,
    add_priority_predictions as _add_priority_predictions,
)

# --- SQL Tools ---
from main.sql_tools import (
    find_missing_fields_df_from_staging as _find_missing_fields_df_from_staging,
    generate_alter_sql_per_field_from_staging as _generate_alter_sql_per_field_from_staging,
    identify_tabular_reports as _identify_tabular_reports,
    generate_select_sql_for_reports as _generate_select_sql_for_reports,
)

#  interactive append
try:
    from main.sql_tools import (
        append_add_field_subtasks_interactive as _append_add_field_subtasks_interactive,
    )
except Exception:  # pragma: no cover
    _append_add_field_subtasks_interactive = None

# --- Feedback Agent ---
from main.feedback_agent import apply_feedback_to_dataframe_values as _apply_feedback_df

# --- IO utils ---
from main.io_utils import (
    read_docx_text as _read_docx_text,
    load_schema_txt as _load_schema_txt,
)

# --- Jira Client ---
from main.jira_client import create_jira_from_df as _create_jira_from_df


# ------------------ PUBLIC API ------------------

DEFAULT_TEMPLATE = """\
Epic: <summary>
  Description: <description>
  - Task: <summary>
    Description: <description>
    - Subtask: <summary>
      Description: <description>
    - Subtask: <summary>
      Description: <description>
  - Task: <summary>
    Description: <description>
"""

# --------- Basic IO ---------
def read_docx_text(file_or_path) -> str:
    return _read_docx_text(file_or_path)

def load_schema_txt(path_or_file) -> str:
    return _load_schema_txt(path_or_file)

# --------- Agents ---------
def document_structure_agent(
    document_text: str,
    format_template: Optional[str] = None,
    model: str = "gpt-4o-mini",
) -> str:
    return _doc_struct_agent(document_text, format_template or DEFAULT_TEMPLATE, model)

def review_and_improve_structure(
    document_structure: str,
    feedback: str = "",
    format_template: Optional[str] = None,
    model: str = "gpt-4o-mini",
) -> str:
    return _review_agent(document_structure, format_template or DEFAULT_TEMPLATE, feedback=feedback, model=model)

# --------- Pipeline (non-SQL) ---------
def build_staging_dataframe(structure_text: str) -> pd.DataFrame:
    return _build_staging_dataframe(structure_text)

def add_labels_to_dataframe(df: pd.DataFrame, model: str = "gpt-4o-mini") -> pd.DataFrame:
    return _add_labels_to_dataframe(df, model=model)

def add_groups_to_dataframe(df: pd.DataFrame, model: str = "gpt-4o-mini") -> pd.DataFrame:
    return _add_groups_to_dataframe(df, model=model)

def add_priority_predictions(df: pd.DataFrame, model: str = "gpt-4o-mini") -> pd.DataFrame:
    
    return _add_priority_predictions(df, model=model)

# --------- SQL Tools ---------
def find_missing_fields_df_from_staging(
    df: pd.DataFrame,
    schema_text: str,
    model: str = "gpt-4o-mini",
) -> pd.DataFrame:
    """
    Απαιτεί στήλη 'label' στο df. Φιλτράρει 'Reporting' και επιστρέφει
    DataFrame με στήλες: missing_field_name, suggested_table, parent_local_id
    (όπως στο δικό σου).
    """
    return _find_missing_fields_df_from_staging(df, schema_text, model=model)

def append_add_field_subtasks_interactive(
    fields_df: pd.DataFrame,
    staging_df: pd.DataFrame,
    *,
    default_label: str = "Data",
    default_group: str = "Data Warehouse Team",
) -> pd.DataFrame:
    
    if _append_add_field_subtasks_interactive is None:
        raise NotImplementedError("append_add_field_subtasks_interactive not found in main.sql_tools")
    return _append_add_field_subtasks_interactive(
        fields_df,
        staging_df,
        default_label=default_label,
        default_group=default_group,
    )

def generate_alter_sql_per_field_from_staging(
    fields_df: pd.DataFrame,
    staging_df: pd.DataFrame,
    schema_text: str,
    model: str = "gpt-4o-mini",
) -> pd.DataFrame:
    
    return _generate_alter_sql_per_field_from_staging(fields_df, staging_df, schema_text, model=model)

def identify_tabular_reports(
    staging_df: pd.DataFrame,
    model: str = "gpt-4o-mini",
) -> pd.DataFrame:
    return _identify_tabular_reports(staging_df, model=model)

def generate_select_sql_for_reports(
    staging_df: pd.DataFrame,
    schema_text: str,
    fields_df: Optional[pd.DataFrame] = None,
    model: str = "gpt-4o-mini",
) -> pd.DataFrame:
    return _generate_select_sql_for_reports(staging_df, schema_text, fields_df, model=model)

# --------- Feedback ---------
def apply_feedback_to_dataframe_values(
    df: pd.DataFrame,
    feedback: str,
    **kwargs
) -> pd.DataFrame:
    return _apply_feedback_df(df, feedback, **kwargs)

# --------- Jira ---------
def create_jira_from_df(
    df: pd.DataFrame,
    *,
    attach_sql: bool = True,
    jira_env: Optional[Dict] = None
) -> Dict:
    
    if jira_env:
        os.environ["JIRA_BASE_URL"] = jira_env.get("base", "")
        os.environ["JIRA_PROJECT_KEY"] = jira_env.get("proj", "")
        os.environ["JIRA_EMAIL"] = jira_env.get("email", "")
        os.environ["JIRA_API_TOKEN"] = jira_env.get("token", "")
        if jira_env.get("assigned_group_cf") is not None:
            os.environ["JIRA_FIELD_ASSIGNED_GROUP"] = jira_env.get("assigned_group_cf") or ""

    return _create_jira_from_df(df, attach_sql=attach_sql, sql_dir="sql_scripts")
