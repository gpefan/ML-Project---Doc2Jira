# app.py
import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
import shutil
import os
from pathlib import Path
import zipfile
import re

import project_api as api

# ===================== Helpers / Constants =====================

INTERNAL_COLUMNS = ["is_tabular_report", "sql_script"]  #

def _slug(s: str) -> str:
    s = (s or "").strip().lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    return re.sub(r"_+", "_", s).strip("_") or "script"

def _safe_sql_text(val) -> str:
    if val is None:
        return ""
    if isinstance(val, float) and pd.isna(val):
        return ""
    text = str(val).strip()
    if not text or text.lower() == "nan":
        return ""
    return text

def write_sql_files_from_staging(df: pd.DataFrame, out_dir: Path) -> list:
    """Γράφει .sql αρχεία για κάθε γραμμή που έχει sql_script (Task/Subtask)."""
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for _, row in df.iterrows():
        sql_text = _safe_sql_text(row.get("sql_script"))
        if not sql_text:
            continue
        local_id = str(row.get("local_id", ""))
        summary = str(row.get("summary", ""))
        sql_clean = sql_text.rstrip()
        if not sql_clean.endswith(";"):
            sql_clean += ";"
        sql_clean += "\n"
        fname = out_dir / f"{local_id}_{_slug(summary)}.sql"
        fname.write_text(sql_clean, encoding="utf-8")
        written.append(str(fname))
    return written

def zip_files(files: list, zip_path: Path) -> str:
    if not files:
        return ""
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            try:
                zf.write(f, arcname=Path(f).name)
            except Exception:
                pass
    return str(zip_path)

def preview_df(df: pd.DataFrame) -> pd.DataFrame:
    
    return df.drop(columns=INTERNAL_COLUMNS, errors="ignore")

def _persist_uploaded_file(uploaded_file, dest_name: str) -> Path:
    
    p = Path(dest_name)
    p.write_bytes(uploaded_file.getbuffer())
    return p

# ===================== LOGIN =====================

if "authenticated" not in st.session_state:
    st.session_state.authenticated = False

if not st.session_state.authenticated:
    st.title("🔐 Login")

    with st.form("login_form"):
        st.subheader("Jira Credentials")
        jira_base_url    = st.text_input("Jira Base URL (https://<org>.atlassian.net)")
        jira_project_key = st.text_input("Jira Project Key")
        jira_email       = st.text_input("Jira Email")
        jira_api_token   = st.text_input("Jira API Token", type="password")

        st.subheader("Optional")
        jira_field_assigned_group = st.text_input(
            "Assigned Group custom field id (optional, e.g. customfield_10124)"
        )

        st.subheader("OpenAI")
        openai_api_key = st.text_input("OpenAI API Key", type="password")

        submit = st.form_submit_button("Login")

    if submit:
        if jira_base_url and jira_project_key and jira_email and jira_api_token:
            # Save session state
            st.session_state.authenticated = True
            st.session_state.JIRA_BASE_URL             = jira_base_url.rstrip("/")
            st.session_state.JIRA_PROJECT_KEY          = jira_project_key
            st.session_state.JIRA_EMAIL                = jira_email
            st.session_state.JIRA_API_TOKEN            = jira_api_token
            st.session_state.JIRA_FIELD_ASSIGNED_GROUP = jira_field_assigned_group or ""
            st.session_state.OPENAI_API_KEY            = openai_api_key

            # Set env vars server-side (για agents/client)
            if openai_api_key:
                os.environ["OPENAI_API_KEY"] = openai_api_key
            os.environ["JIRA_BASE_URL"]  = st.session_state.JIRA_BASE_URL
            os.environ["JIRA_PROJECT_KEY"] = st.session_state.JIRA_PROJECT_KEY
            os.environ["JIRA_EMAIL"]       = st.session_state.JIRA_EMAIL
            os.environ["JIRA_API_TOKEN"]   = st.session_state.JIRA_API_TOKEN
            os.environ["JIRA_FIELD_ASSIGNED_GROUP"] = st.session_state.JIRA_FIELD_ASSIGNED_GROUP

            st.success("✅ Login successful!")
            st.rerun()
        else:
            st.error("Please fill in all required fields (Base URL, Project Key, Email, Token).")
    st.stop()

# ===================== MAIN APP =====================

st.title("📋 AI Agents → Jira Pipeline App")
st.write(f"Welcome, **{st.session_state.JIRA_EMAIL}** 👋")

# Sidebar: Logout
with st.sidebar:
    if st.button("🚪 Logout"):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()

# Reset process ( pipeline state + sql_scripts)
if st.button("🔄 Reset Process"):
    keys_to_clear = [
        "uploaded_doc", "uploaded_schema", "structure_text",
        "staging_df", "final_df", "fields_df", "id_map",
        "SCHEMA_TEXT", "FIELDS_DF", "SELECTED_MISSING_FIELDS",
        "MISSING_EXISTS", "MISSING_ADD",
        "enriched"
    ]
    for k in keys_to_clear:
        st.session_state.pop(k, None)
    if Path("sql_scripts").exists():
        shutil.rmtree("sql_scripts", ignore_errors=True)
    st.success("Process reset. Please upload files again.")

# -------- Uploads --------
doc_file = st.file_uploader("Upload Project Document (.docx)", type=["docx"], key="docx_file")
schema_file = st.file_uploader("Upload Database Schema (.txt)", type=["txt"], key="txt_file")

include_sql    = st.checkbox("Include SQL (missing fields + report SELECTs)", value=False)
predict_groups = st.checkbox("Predict Assignee Group (optional)", value=False)
dry_run        = st.checkbox("Dry Run (only show payloads, don't call Jira)", value=True)

tree_layout = st.selectbox("Tree Layout Direction", ["UD", "LR"], index=0)
show_tree   = st.checkbox("Show hierarchy tree", value=True)

# -------- Agents --------
if st.button("▶️ Run Agents"):
    if not doc_file:
        st.error("Please upload a .docx file to continue.")
    else:
        with st.spinner("Processing document..."):
            doc_text = api.read_docx_text(doc_file)  # file-like safe
            s1 = api.document_structure_agent(doc_text)
            s2 = api.review_and_improve_structure(s1)

            st.session_state.structure_text = s2
            st.session_state.staging_df = api.build_staging_dataframe(s2)

            # reset downstream state
            for k in ["final_df","FIELDS_DF","SCHEMA_TEXT","SELECTED_MISSING_FIELDS","MISSING_EXISTS","MISSING_ADD"]:
                st.session_state.pop(k, None)
            st.session_state.enriched = False

        st.success("Agents finished. Review structure below.")

# ===================== FLOW CONTROL =====================
# (A) Structure stage, (B) Final stage
if "staging_df" in st.session_state and not st.session_state.get("enriched"):
    # ---------- (A) STRUCTURE STAGE ----------
    st.subheader("Generated Structure")
    with st.expander("Show Structure Text"):
        st.text(st.session_state.structure_text)

    st.dataframe(preview_df(st.session_state.staging_df))

    approve = st.radio(
        "Are you okay with this structure?",
        ["(Please choose)", "Yes", "No"],
        index=0,
        key="structure_approve_radio"
    )

    if approve == "(Please choose)":
        st.info("👉 Please confirm if you are okay with the structure.")
        st.stop()

    if approve == "No":
        feedback = st.text_area("Provide feedback for refinement")
        if st.button("Re-run Review Agent"):
            s2 = api.review_and_improve_structure(
                st.session_state.structure_text,
                feedback=feedback
            )
            st.session_state.structure_text = s2
            st.session_state.staging_df = api.build_staging_dataframe(s2)
            st.success("Structure refined. Please review again.")
            st.rerun()
        st.stop()

    # -------- Optional SQL interactions --------
    if include_sql:
        if not schema_file:
            st.warning("Include SQL is ON but no schema uploaded.")
        else:
            #  
            if "SCHEMA_TEXT" not in st.session_state:
                tmp_path = _persist_uploaded_file(schema_file, "uploaded_schema.txt")
                st.session_state.SCHEMA_TEXT = api.load_schema_txt(str(tmp_path))

            st.markdown("#### 🧭 Missing Fields (manual flow)")
            col_a, col_b = st.columns([1,1])

            with col_a:
                if st.button("🔍 Analyze Missing Fields", key="analyze_missing_btn"):
                    # 
                    df_for_missing = st.session_state.staging_df
                    if "label" not in df_for_missing.columns:
                        df_for_missing = api.add_labels_to_dataframe(df_for_missing.copy())

                    fields_df = api.find_missing_fields_df_from_staging(
                        df_for_missing, st.session_state.SCHEMA_TEXT
                    )
                    st.session_state.FIELDS_DF = fields_df
                    st.session_state.SELECTED_MISSING_FIELDS = []
                    st.session_state.MISSING_EXISTS = {}
                    st.session_state.MISSING_ADD = {}
                    st.success(f"Analysis complete. Found {len(fields_df)} candidate fields.")

            with col_b:
                if st.button("♻️ Re-run Analysis", key="reanalyze_missing_btn"):
                    st.session_state.pop("FIELDS_DF", None)
                    st.session_state.SELECTED_MISSING_FIELDS = []
                    st.session_state.MISSING_EXISTS = {}
                    st.session_state.MISSING_ADD = {}
                    st.rerun()

            # 
            if isinstance(st.session_state.get("FIELDS_DF"), pd.DataFrame):
                fields_df = st.session_state.FIELDS_DF

                if fields_df.empty:
                    st.info("No missing fields detected.")
                else:
                    st.dataframe(fields_df)

                    # 1)  
                    chosen = st.multiselect(
                        "Select which fields to review/append as subtasks",
                        options=fields_df["missing_field_name"].tolist(),
                        default=st.session_state.get("SELECTED_MISSING_FIELDS", []),
                        key="missing_fields_multiselect"
                    )
                    st.session_state.SELECTED_MISSING_FIELDS = chosen

                    # 2) 
                    #    - Does it exist already? (Yes/No)
                    #    - Do you want to add it? (Yes/No)
                    if chosen:
                        st.markdown("##### Decisions per field")
                        subset = fields_df[fields_df["missing_field_name"].isin(chosen)]
                        for _, r in subset.iterrows():
                            fname = str(r["missing_field_name"]).strip()
                            tname = str(r["suggested_table"]).strip()

                            c1, c2 = st.columns([1,1], gap="small")

                            with c1:
                                st.selectbox(
                                    f"Does field '{fname}' already exist in the database?",
                                    ["(choose)", "Yes", "No"],
                                    index=["(choose)","Yes","No"].index(
                                        st.session_state.get("MISSING_EXISTS", {}).get(fname, "(choose)")
                                    ),
                                    key=f"exists_{fname}",
                                )
                            with c2:
                                st.selectbox(
                                    f"Add '{fname}' to table '{tname}' as a subtask?",
                                    ["(choose)", "Yes", "No"],
                                    index=["(choose)","Yes","No"].index(
                                        st.session_state.get("MISSING_ADD", {}).get(fname, "(choose)")
                                    ),
                                    key=f"add_{fname}",
                                )

                            # sync σε state maps
                            st.session_state.MISSING_EXISTS[fname] = st.session_state.get(f"exists_{fname}", "(choose)")
                            st.session_state.MISSING_ADD[fname] = st.session_state.get(f"add_{fname}", "(choose)")

                    # 3) 
                    if st.button("➕ Append Selected Fields", key="append_selected_btn"):
                        if not chosen:
                            st.warning("Please select at least one field to append.")
                        else:
                            #  αν Exists==Yes -> skip, αν Add!=Yes -> skip, αλλιώς create subtask
                            df = st.session_state.staging_df.copy()

                            # helper next_sub_id: U{n}
                            def next_sub_id(existing_ids: pd.Series) -> str:
                                max_n = 0
                                for v in existing_ids.dropna().astype(str):
                                    m = re.match(r"U(\d+)$", v.strip(), re.IGNORECASE)
                                    if m:
                                        max_n = max(max_n, int(m.group(1)))
                                return f"U{max_n + 1}"

                            before = len(df)
                            subset = fields_df[fields_df["missing_field_name"].isin(chosen)]
                            for _, r in subset.iterrows():
                                fname = str(r["missing_field_name"]).strip()
                                tname = str(r["suggested_table"]).strip()
                                parent = str(r["parent_local_id"]).strip()

                                exists_ans = (st.session_state.MISSING_EXISTS or {}).get(fname, "(choose)")
                                add_ans    = (st.session_state.MISSING_ADD or {}).get(fname, "(choose)")

                                # emulate exactly your interactive flow
                                if exists_ans == "Yes":
                                    # Skipping — already exists
                                    continue
                                if add_ans != "Yes":
                                    # Skipping — not adding
                                    continue

                                new_id = next_sub_id(df["local_id"]) if "local_id" in df.columns else "U1"
                                summary = f'Add field "{fname}" to table "{tname}"'
                                description = (
                                    f'Implement changes to add the field "{fname}" into table "{tname}", '
                                    f'including ETL and database updates.'
                                )

                                new_row = {
                                    "local_id": new_id,
                                    "summary": summary,
                                    "description": description,
                                    "issue_type": "Subtask",
                                    "parent_local_id": parent,
                                    "label": "Data",  # default_label 
                                    "assignee_group": "Data Warehouse Team",  # default_group 
                                }
                                df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

                            after = len(df)
                            st.session_state.staging_df = df
                            # Αν υπήρχε φτιαγμένο final, το ακυρώνουμε για να χτιστεί με τα νέα rows
                            st.session_state.pop("final_df", None)
                            st.session_state.enriched = False

                            st.success(f"Subtasks appended: {after - before}. Now build the Final Dataset.")

    # -------- Build Final Dataset (τρέχει ΜΙΑ φορά, με κουμπί) --------
    if st.button("➡️ Build Final Dataset"):
        with st.spinner("Building final dataset (labels, groups, SQL-selects, priorities)..."):
            final_df = st.session_state.staging_df.copy()

            # labels
            final_df = api.add_labels_to_dataframe(final_df)

            # groups (optional)
            if predict_groups:
                final_df = api.add_groups_to_dataframe(final_df)

            # SQL report SELECTs (αν έχουμε schema & ενεργό include_sql)
            schema_text = st.session_state.get("SCHEMA_TEXT", "")
            fields_df_cache = st.session_state.get("FIELDS_DF", pd.DataFrame())
            if include_sql and schema_text:
                final_df = api.identify_tabular_reports(final_df)
                final_df = api.generate_select_sql_for_reports(final_df, schema_text, fields_df_cache)

            # priorities 
            final_df = api.add_priority_predictions(final_df, model="gpt-4o-mini")

            st.session_state.final_df = final_df
            st.session_state.enriched = True

        st.success("Final dataset ready.")
        st.rerun()

    st.stop()  # Μένουμε στο Structure Stage μέχρι να πατηθεί Build Final Dataset

# ---------- (B) FINAL STAGE ----------
if st.session_state.get("enriched") and "final_df" in st.session_state:
    st.subheader("📊 Final DataFrame")
    st.dataframe(preview_df(st.session_state.final_df))

    # Tree (στο τελικό df)
    if show_tree:
        try:
            from main.viz_utils import render_jira_hierarchy_tree
            html = render_jira_hierarchy_tree(st.session_state.final_df, direction=tree_layout)
            components.html(html, height=650, scrolling=True)
        except Exception:
            st.warning("Tree visualization not available.")

    # -------- FINAL FEEDBACK LOOP --------
    st.markdown("### ✅ Final Approval")
    final_approve = st.radio(
        "Are you okay with this *final* outcome (labels/groups/priorities/text)?",
        ["(Please choose)", "Yes", "No"],
        index=0,
        key="final_approve_radio"
    )

    if final_approve == "(Please choose)":
        st.stop()

    if final_approve == "No":
        final_feedback = st.text_area(
            "Provide feedback (values only: labels, groups, priority, summary/description)"
        )
        if st.button("Apply Feedback"):
            fb = (final_feedback or "").strip()

            # Γρήγορη εντολή: set all priorities (πάνω στο ΤΕΛΙΚΟ df)
            m = re.search(r"(?i)\bset\s+priorit(?:y|ies)\b.*?(?:to|=)\s*(highest|high|medium|low|lowest)\b", fb)
            if m and "priority" in st.session_state.final_df.columns:
                target = m.group(1).capitalize()
                df = st.session_state.final_df.copy()
                df["priority"] = target
                st.session_state.final_df = df
                st.success(f"All priorities set to **{target}**.")
                st.rerun()

            # Γενικό free-form feedback πάνω στο ΤΕΛΙΚΟ df
            st.session_state.final_df = api.apply_feedback_to_dataframe_values(
                st.session_state.final_df,
                feedback=fb,
                allowed_columns=["label", "assignee_group", "priority", "summary", "description"],
                extra_context_columns=["label", "assignee_group", "priority"],
                model="gpt-4o-mini",
                temperature=0.0,
            )
            st.success("Feedback applied to final dataset.")
            st.rerun()
    else:
        # Yes → proceed to Jira/Downloads
        pass

    # -------- Jira creation / Dry Run --------
    if st.button("🚀 Create Jira Issues"):
        if dry_run:
            st.subheader("Dry Run Mode (no Jira call)")
            st.dataframe(preview_df(st.session_state.final_df))
        else:
            with st.spinner("Creating Jira issues..."):
                jira_env = {
                    "base": st.session_state.JIRA_BASE_URL,
                    "proj": st.session_state.JIRA_PROJECT_KEY,
                    "email": st.session_state.JIRA_EMAIL,
                    "token": st.session_state.JIRA_API_TOKEN,
                }
                id_map = api.create_jira_from_df(
                    st.session_state.final_df,
                    attach_sql=include_sql,
                    jira_env=jira_env,
                )
                st.session_state.id_map = id_map
            st.success("✅ Jira issues created")
            st.json(st.session_state.id_map)

    # -------- Downloads (CSV + SQL zip) --------
    st.subheader("⬇️ Downloads")
    if st.session_state.final_df is not None:
        csv_data = preview_df(st.session_state.final_df).to_csv(index=False).encode("utf-8")
        st.download_button("Download Final DataFrame (CSV)", data=csv_data,
                           file_name="final_df.csv", mime="text/csv")

    # Εξαγωγή SQL από το τελικό df (Tasks & Subtasks)
    sql_dir = Path("sql_scripts")
    files_written = write_sql_files_from_staging(st.session_state.final_df, sql_dir)
    if files_written:
        zip_path = Path("sql_scripts_bundle.zip")
        zip_file = zip_files(files_written, zip_path)
        if zip_file:
            with open(zip_file, "rb") as fh:
                st.download_button(
                    "Download generated SQL (zip)",
                    data=fh.read(),
                    file_name=Path(zip_file).name,
                    mime="application/zip",
                    help="Κατεβάστε όλα τα SQL που παράχθηκαν"
                )
    elif include_sql:
        st.info("Δεν υπάρχουν SQL scripts για εξαγωγή.")
